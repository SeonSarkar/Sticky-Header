package com.example.sticky.model;

/**
 * Created by Kiran Gyawali on 10/22/2019.
 */

public class RecyclerViewItem {

    boolean isHeader;

}
